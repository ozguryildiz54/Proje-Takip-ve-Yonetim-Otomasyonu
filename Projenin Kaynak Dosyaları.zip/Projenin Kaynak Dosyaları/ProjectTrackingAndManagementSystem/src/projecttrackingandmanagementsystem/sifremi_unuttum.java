package projecttrackingandmanagementsystem;
//Kutuphaneler
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class sifremi_unuttum extends javax.swing.JFrame 
{
    //Global Degiskenler
      //Veritabanı sorgu referans nesneleri
        Connection baglanti=null;  
        PreparedStatement sorgu=null;
        ResultSet sonuc=null;
      //Mouse imlec nesnesi
        Cursor imlec=new Cursor(Cursor.HAND_CURSOR);//İmlec sinifindan bir nesne turetilir ve yapilandirici metoduna bir imlec tanimlanir.
        //Yapilandirici metoduna tanimlanan imlec : Cursor.HAND_CURSOR
    
    public sifremi_unuttum() //Penceremizin yapilandirici metodu 
    {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        onayla_btn = new javax.swing.JButton();
        temizle_btn = new javax.swing.JButton();
        gizli_yanit_text = new javax.swing.JPasswordField();
        gizli_yanit_label = new javax.swing.JLabel();
        userKey_text = new javax.swing.JPasswordField();
        sifre_label = new javax.swing.JLabel();
        username_label = new javax.swing.JLabel();
        username_text = new javax.swing.JTextField();
        geri_btn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        username_label1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        setTitle("Şifre Değiştirme Paneli");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(239, 239, 239));

        onayla_btn.setBackground(new java.awt.Color(51, 153, 255));
        onayla_btn.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 14)); // NOI18N
        onayla_btn.setForeground(new java.awt.Color(255, 255, 255));
        onayla_btn.setText("Onayla");
        onayla_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                onayla_btnMouseEntered(evt);
            }
        });
        onayla_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onayla_btnActionPerformed(evt);
            }
        });

        temizle_btn.setBackground(new java.awt.Color(51, 153, 255));
        temizle_btn.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 14)); // NOI18N
        temizle_btn.setForeground(new java.awt.Color(255, 255, 255));
        temizle_btn.setText("Temizle");
        temizle_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                temizle_btnMouseEntered(evt);
            }
        });
        temizle_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                temizle_btnActionPerformed(evt);
            }
        });

        gizli_yanit_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        gizli_yanit_text.setForeground(new java.awt.Color(0, 255, 51));

        gizli_yanit_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        gizli_yanit_label.setForeground(new java.awt.Color(102, 153, 255));
        gizli_yanit_label.setText("Gizli Yanıt");

        userKey_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        userKey_text.setForeground(new java.awt.Color(0, 255, 51));
        userKey_text.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userKey_textMouseClicked(evt);
            }
        });

        sifre_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        sifre_label.setForeground(new java.awt.Color(102, 153, 255));
        sifre_label.setText("Yeni Parola");

        username_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        username_label.setForeground(new java.awt.Color(102, 153, 255));
        username_label.setText("Kullanıcı Adı");

        username_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        username_text.setForeground(new java.awt.Color(0, 255, 51));
        username_text.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                username_textMouseClicked(evt);
            }
        });

        geri_btn.setBackground(new java.awt.Color(51, 153, 255));
        geri_btn.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 14)); // NOI18N
        geri_btn.setForeground(new java.awt.Color(255, 255, 255));
        geri_btn.setText("Geri");
        geri_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                geri_btnMouseEntered(evt);
            }
        });
        geri_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geri_btnActionPerformed(evt);
            }
        });

        username_label1.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 36)); // NOI18N
        username_label1.setForeground(new java.awt.Color(0, 153, 204));
        username_label1.setText("Şifre Değiştir");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projecttrackingandmanagementsystem/unnamed.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(geri_btn)
                        .addGap(109, 109, 109)
                        .addComponent(username_label1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(temizle_btn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                                .addComponent(onayla_btn))
                            .addComponent(username_label)
                            .addComponent(sifre_label, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gizli_yanit_label, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gizli_yanit_text)
                            .addComponent(userKey_text)
                            .addComponent(username_text))))
                .addGap(44, 47, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_label1)
                    .addComponent(geri_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(username_label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(username_text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(sifre_label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(userKey_text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(gizli_yanit_label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(gizli_yanit_text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(temizle_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(onayla_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(32, 32, 32))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void onayla_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onayla_btnActionPerformed
        
        try {
            Class.forName("com.mysql.jdbc.Driver");//Veritabanına baglanti surucusu tanimlandi.
            //Alt satirda veritabanimizin baglanti adresini tanimliyoruz.
              baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
            sorgu=baglanti.prepareStatement("select * from user_login where username=? and gizli_yanit=?");//Veritabanimizda ki yapmak istediimiz sorgu burada tanimlanir.
            //Yukaridaki sorguda ? yerine textbox komponentlerinin degerleri onceden bilinmediginden ve degisken oldugundan
            //daha sonradan o degerler where sarti icine yuklenecektir. 
            //textbox komponentlerinin degerleri ? yerine yuklenir.
              sorgu.setString(1,username_text.getText());
              sorgu.setString(2,gizli_yanit_text.getText());
            //Sorgu calistirilir
              sonuc=sorgu.executeQuery();
            if(sonuc.next())    //Veritabaninda ki veriler ile komponentlerde ki verilerin eslesmesi karsilastirilir.
            {
                //Sonuclar ayni ise sifre degistirme basarili bir sekilde giris yapmis olur.
                  sorgu.executeUpdate("UPDATE user_login SET password ='"+userKey_text.getText()+"'"); //Sql sorgusu ile password degeri guncellenir.
                //Alt satirda kullaniciya uyari mesaji verir bu yapi uyari ve bilgilendirme mesaji icin kullanilir.
                  JOptionPane.showMessageDialog(null,"Şifre Başarılı Bir Şekilde Değiştirildi.","Bilgilendirme",JOptionPane.WARNING_MESSAGE);
            }
            else //Degerler ayni degilse sifre degistirelememis olur.
            {
                JOptionPane.showMessageDialog(null,"Şifre Değiştirilemedi","Hata",JOptionPane.WARNING_MESSAGE);
                //Texbox icinde ki yaziyi temizler.
                  username_text.setText("");
                  userKey_text.setText("");
                  gizli_yanit_text.setText("");
            }           
        } 
        //Beklenmedik durumlar bu blokta degerlendirilir ve programin etkinligi surdurulur.
          catch (ClassNotFoundException ex) 
          {
                Logger.getLogger(sifremi_unuttum.class.getName()).log(Level.SEVERE, null, ex);
          } 
          catch (SQLException ex) 
          {
                Logger.getLogger(sifremi_unuttum.class.getName()).log(Level.SEVERE, null, ex);
          }   
    }//GEN-LAST:event_onayla_btnActionPerformed

    private void temizle_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_temizle_btnActionPerformed
        //Texbox icinde ki yaziyi temizler.
          username_text.setText("");
          userKey_text.setText("");
          gizli_yanit_text.setText("");
    }//GEN-LAST:event_temizle_btnActionPerformed

    private void userKey_textMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userKey_textMouseClicked
        //Textbox'a tiklanildiginda texbox icinde ki yaziyi temizler.
        userKey_text.setText("");
    }//GEN-LAST:event_userKey_textMouseClicked

    private void username_textMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_username_textMouseClicked
        //Textbox'a tiklanildiginda texbox icinde ki yaziyi temizler.
        username_text.setText("");
    }//GEN-LAST:event_username_textMouseClicked

    private void geri_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geri_btnActionPerformed
        //Kullanici giris penceresine geri doner.
          main form=new main();
          form.show();
        this.hide();//Sİfre degistirme penceresi gizlenir.
    }//GEN-LAST:event_geri_btnActionPerformed

    private void geri_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_geri_btnMouseEntered
        geri_btn.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_geri_btnMouseEntered

    private void temizle_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_temizle_btnMouseEntered
        temizle_btn.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_temizle_btnMouseEntered

    private void onayla_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_onayla_btnMouseEntered
        onayla_btn.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_onayla_btnMouseEntered

    public static void main(String args[]) //Penceremizin main metodu 
    {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(sifremi_unuttum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(sifremi_unuttum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(sifremi_unuttum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(sifremi_unuttum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new sifremi_unuttum().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton geri_btn;
    private javax.swing.JLabel gizli_yanit_label;
    private javax.swing.JPasswordField gizli_yanit_text;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton onayla_btn;
    private javax.swing.JLabel sifre_label;
    private javax.swing.JButton temizle_btn;
    private javax.swing.JPasswordField userKey_text;
    private javax.swing.JLabel username_label;
    private javax.swing.JLabel username_label1;
    private javax.swing.JTextField username_text;
    // End of variables declaration//GEN-END:variables
}
