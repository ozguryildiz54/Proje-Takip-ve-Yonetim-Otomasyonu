package projecttrackingandmanagementsystem;
//Kutuphaneler
import java.awt.Cursor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.print.attribute.Size2DSyntax.MM;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class yeni_proje extends javax.swing.JFrame 
{
    //Global Degiskenler ve Referans Nesneleri
      //Veritabanı sorgu referans nesneleri
        Connection baglanti=null;  
        Statement sorgu=null;
        ResultSet sonuc=null;
      //Mouse imlec nesnesi
        Cursor imlec=new Cursor(Cursor.HAND_CURSOR);//İmlec sinifindan bir nesne turetilir ve yapilandirici metoduna bir imlec tanimlanir.
        //Yapilandirici metoduna tanimlanan imlec : Cursor.HAND_CURSOR        
      File nesne_file;    //Dosya sinifinin referans nesnesi.
      final JFileChooser jfcdosya_sec=new JFileChooser(); //Dosya secimi sinifinin referans nesnesi.
      public String sdosyakonumu="C:\\Projeler"; //Varsayilan dosya konumu.
      
    public yeni_proje() //Penceremizin yapilandirici metodu 
    {
        initComponents();        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");//Veritabanına baglanti surucusu tanimlandi.
            //Alt satirda veritabanimizin baglanti adresini tanimliyoruz.
              baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
            sorgu=baglanti.createStatement(); //Sorgu icin Connection sinifi ile  Statement sinifi arasinda bir bag olusturulur.
            sonuc=sorgu.executeQuery("select konum from dosya_konumu"); //Varsayilan konum bilgisini seciyor.Sonuclar ResultSet sinifinin nesnesine yuklenir.
            while(sonuc.next()) //Sonuclar tek tek gezilir.
            {
                varsayilan_konum_text.setText(sonuc.getString(1)); // Konum textbox'a yazilir.
                konum_text.setText(sonuc.getString(1)); // Konum textbox'a yazilir.
            }
     } 
     //Beklenmedik durumlar bu blokta degerlendirilir ve programin etkinligi surdurulur.
       catch (SQLException ex) 
       {
            Logger.getLogger(dosya_konumu.class.getName()).log(Level.SEVERE, null, ex);
       } 
       catch (ClassNotFoundException ex) 
       {
            Logger.getLogger(dosya_konumu.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField9 = new javax.swing.JTextField();
        jDialog1 = new javax.swing.JDialog();
        jLabel15 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jTextField30 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jFrame1 = new javax.swing.JFrame();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuBar3 = new javax.swing.JMenuBar();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        kaydet_buton = new javax.swing.JButton();
        islemler_label = new javax.swing.JLabel();
        geri_buton = new javax.swing.JButton();
        proje_adi_label = new javax.swing.JLabel();
        proje_adi_text = new javax.swing.JTextField();
        para_text = new javax.swing.JTextField();
        musteri_adi_label = new javax.swing.JLabel();
        para_label = new javax.swing.JLabel();
        musteri_ad_text = new javax.swing.JTextField();
        para_combobox = new javax.swing.JComboBox();
        musteri_telefon_text = new javax.swing.JTextField();
        musteri_telefon_label = new javax.swing.JLabel();
        son_tarih_date = new com.toedter.calendar.JDateChooser();
        son_tarih_label = new javax.swing.JLabel();
        ilk_tarih_date = new com.toedter.calendar.JDateChooser();
        ilk_tarih_label = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        proje_tanim_text = new javax.swing.JTextPane();
        proje_tanimi_label = new javax.swing.JLabel();
        musteri_not_label = new javax.swing.JLabel();
        musteri_mail_text = new javax.swing.JTextField();
        masaustu_checkbox = new javax.swing.JCheckBox();
        varsayilan_konum_text = new java.awt.TextField();
        konum_text = new java.awt.TextField();
        sematik_checkbox = new javax.swing.JCheckBox();
        gomulu_checkbox = new javax.swing.JCheckBox();
        pcb_checkbox = new javax.swing.JCheckBox();
        web_checkbox = new javax.swing.JCheckBox();
        temizle_buton = new javax.swing.JButton();
        proje_tipi_label = new javax.swing.JLabel();
        varsayilan_konum_label = new javax.swing.JLabel();
        gozat_buton = new javax.swing.JButton();
        konum_label = new javax.swing.JLabel();
        mobil_checkbox = new javax.swing.JCheckBox();
        donanim_checkbox = new javax.swing.JCheckBox();
        jLabel3 = new javax.swing.JLabel();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jLabel15.setText("Bitiş Tarihi");

        jLabel22.setText("Proje Gerçekleştirim (Gün)");

        jLabel30.setText("Müşteri Borç");

        jLabel39.setText("Zarar Miktarı");

        jFrame1.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel6.setBackground(new java.awt.Color(153, 204, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Öncelik", "Proje Adı", "Proje Tipi", "Amaç", "Açıklama", "Son Durum", "Hatırlatma İçeriği", "İhtiyaç Listesi", "Başlangıç Zamanı", "Alarm zamanı", "Tahmini Bitiş", "Proje Teslim", "İhtiyaTemini", "Tanım Süresi", "İhtiyaç Süresi", "Tasarım Süresi", "Gerçekleştirim Süresi", "Test Süresi", "Bakım Süresi", "Müşteri Adı"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1713, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 652, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Araçlar");

        jButton9.setForeground(new java.awt.Color(0, 153, 204));
        jButton9.setText("Düzenle");
        jButton9.setMaximumSize(new java.awt.Dimension(71, 25));
        jButton9.setMinimumSize(new java.awt.Dimension(71, 25));

        jButton10.setForeground(new java.awt.Color(0, 153, 204));
        jButton10.setText("Kaydet");

        jButton11.setForeground(new java.awt.Color(0, 153, 204));
        jButton11.setText("Sil");
        jButton11.setMaximumSize(new java.awt.Dimension(71, 25));
        jButton11.setMinimumSize(new java.awt.Dimension(71, 25));
        jButton11.setPreferredSize(new java.awt.Dimension(71, 25));

        jButton12.setForeground(new java.awt.Color(0, 153, 204));
        jButton12.setText("Kapat");

        jButton13.setText("Geri");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setForeground(new java.awt.Color(0, 153, 204));
        jButton14.setText("Görüntüle");

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame1Layout.createSequentialGroup()
                .addGroup(jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrame1Layout.createSequentialGroup()
                        .addContainerGap(37, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(52, 52, 52))
                    .addGroup(jFrame1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jButton11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jFrame1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("File");
        jMenuBar3.add(jMenu5);

        jMenu6.setText("Edit");
        jMenuBar3.add(jMenu6);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Yeni Proje Kaydı");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        kaydet_buton.setBackground(new java.awt.Color(51, 153, 255));
        kaydet_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        kaydet_buton.setForeground(java.awt.Color.white);
        kaydet_buton.setText("Kaydet");
        kaydet_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kaydet_butonMouseEntered(evt);
            }
        });
        kaydet_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kaydet_butonActionPerformed(evt);
            }
        });

        islemler_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        islemler_label.setForeground(new java.awt.Color(153, 51, 0));
        islemler_label.setText("İşlemler");

        geri_buton.setBackground(new java.awt.Color(51, 153, 255));
        geri_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        geri_buton.setForeground(java.awt.Color.white);
        geri_buton.setText("Geri");
        geri_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                geri_butonMouseEntered(evt);
            }
        });
        geri_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geri_butonActionPerformed(evt);
            }
        });

        proje_adi_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        proje_adi_label.setForeground(new java.awt.Color(51, 51, 51));
        proje_adi_label.setText("Proje Adı");

        proje_adi_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        proje_adi_text.setForeground(new java.awt.Color(51, 153, 255));
        proje_adi_text.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                proje_adi_textMouseClicked(evt);
            }
        });

        para_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        para_text.setForeground(new java.awt.Color(51, 153, 255));

        musteri_adi_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        musteri_adi_label.setForeground(new java.awt.Color(51, 51, 51));
        musteri_adi_label.setText("Müşteri Adı ve Soyadı");

        para_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        para_label.setForeground(new java.awt.Color(51, 51, 51));
        para_label.setText("Proje Fiyatı");

        musteri_ad_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        musteri_ad_text.setForeground(new java.awt.Color(51, 153, 255));

        para_combobox.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        para_combobox.setForeground(new java.awt.Color(51, 51, 51));
        para_combobox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-Seçim Yapılmadı", "-Türk Lirası", "-Dolar", "-Euro", "-Yuan" }));
        para_combobox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                para_comboboxMouseEntered(evt);
            }
        });

        musteri_telefon_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        musteri_telefon_text.setForeground(new java.awt.Color(51, 153, 255));

        musteri_telefon_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        musteri_telefon_label.setForeground(new java.awt.Color(51, 51, 51));
        musteri_telefon_label.setText("Müşteri Telefon");

        son_tarih_date.setForeground(new java.awt.Color(51, 153, 255));

        son_tarih_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        son_tarih_label.setForeground(new java.awt.Color(51, 51, 51));
        son_tarih_label.setText("Tahmini Bitiş Tarihi");

        ilk_tarih_date.setForeground(new java.awt.Color(51, 153, 255));

        ilk_tarih_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        ilk_tarih_label.setForeground(new java.awt.Color(51, 51, 51));
        ilk_tarih_label.setText("Başlangıç Tarihi");

        proje_tanim_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        proje_tanim_text.setForeground(new java.awt.Color(51, 153, 255));
        jScrollPane2.setViewportView(proje_tanim_text);

        proje_tanimi_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        proje_tanimi_label.setText("Proje Tanımı");

        musteri_not_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        musteri_not_label.setForeground(new java.awt.Color(51, 51, 51));
        musteri_not_label.setText("Müşteri Mail");

        musteri_mail_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        musteri_mail_text.setForeground(new java.awt.Color(51, 153, 255));

        masaustu_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        masaustu_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        masaustu_checkbox.setText("Masaüstü Uygulaması");
        masaustu_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                masaustu_checkboxMouseEntered(evt);
            }
        });

        varsayilan_konum_text.setEnabled(false);
        varsayilan_konum_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        varsayilan_konum_text.setForeground(new java.awt.Color(51, 153, 255));

        konum_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        konum_text.setForeground(new java.awt.Color(51, 153, 255));
        konum_text.setText(" ");

        sematik_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        sematik_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        sematik_checkbox.setText("Şematik");
        sematik_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sematik_checkboxMouseClicked(evt);
            }
        });

        gomulu_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        gomulu_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        gomulu_checkbox.setText("Gömülü Yazılım");
        gomulu_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                gomulu_checkboxMouseEntered(evt);
            }
        });

        pcb_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        pcb_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        pcb_checkbox.setText("PCB");
        pcb_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pcb_checkboxMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pcb_checkboxMouseEntered(evt);
            }
        });

        web_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        web_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        web_checkbox.setText("Web Yazılımı");
        web_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                web_checkboxMouseEntered(evt);
            }
        });

        temizle_buton.setBackground(new java.awt.Color(51, 153, 255));
        temizle_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 12)); // NOI18N
        temizle_buton.setForeground(java.awt.Color.white);
        temizle_buton.setText("Temizle");
        temizle_buton.setMaximumSize(new java.awt.Dimension(71, 25));
        temizle_buton.setMinimumSize(new java.awt.Dimension(71, 25));
        temizle_buton.setPreferredSize(new java.awt.Dimension(71, 25));
        temizle_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                temizle_butonMouseEntered(evt);
            }
        });

        proje_tipi_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        proje_tipi_label.setForeground(new java.awt.Color(153, 51, 0));
        proje_tipi_label.setText("Proje Tipini Seçiniz");

        varsayilan_konum_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        varsayilan_konum_label.setForeground(new java.awt.Color(51, 51, 51));
        varsayilan_konum_label.setText("Varsayılan Konum:");

        gozat_buton.setBackground(new java.awt.Color(51, 153, 255));
        gozat_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        gozat_buton.setForeground(java.awt.Color.white);
        gozat_buton.setText("Gözat");
        gozat_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                gozat_butonMouseEntered(evt);
            }
        });
        gozat_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gozat_butonActionPerformed(evt);
            }
        });

        konum_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        konum_label.setForeground(new java.awt.Color(51, 51, 51));
        konum_label.setText("Dosya Konumu:");

        mobil_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        mobil_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        mobil_checkbox.setText("Mobil Yazılım");
        mobil_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mobil_checkboxMouseEntered(evt);
            }
        });

        donanim_checkbox.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        donanim_checkbox.setForeground(new java.awt.Color(51, 51, 51));
        donanim_checkbox.setText("Donanım");
        donanim_checkbox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                donanim_checkboxMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                donanim_checkboxMouseEntered(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 51, 0));
        jLabel3.setText("Yeni Proje Oluştur");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(musteri_adi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(450, 450, 450)
                        .addComponent(musteri_telefon_text, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(masaustu_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(gomulu_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(varsayilan_konum_text, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(450, 450, 450)
                        .addComponent(son_tarih_date, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(790, 790, 790)
                        .addComponent(proje_tanimi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(210, 210, 210)
                        .addComponent(konum_label, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(450, 450, 450)
                        .addComponent(ilk_tarih_date, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(750, 750, 750)
                        .addComponent(pcb_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addComponent(mobil_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(konum_text, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(700, 700, 700)
                        .addComponent(musteri_mail_text, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(musteri_ad_text, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(680, 680, 680)
                        .addComponent(gozat_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(460, 460, 460)
                        .addComponent(son_tarih_label, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(240, 240, 240)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(820, 820, 820)
                        .addComponent(sematik_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(geri_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(790, 790, 790)
                        .addComponent(musteri_not_label, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(varsayilan_konum_label, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(islemler_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(proje_adi_text, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(para_label, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(700, 700, 700)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(470, 470, 470)
                        .addComponent(ilk_tarih_label, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(kaydet_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addComponent(web_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(para_text, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(proje_adi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(730, 730, 730)
                        .addComponent(donanim_checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(para_combobox, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(480, 480, 480)
                        .addComponent(musteri_telefon_label, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(temizle_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(440, 440, 440)
                        .addComponent(proje_tipi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(290, 290, 290)
                        .addComponent(musteri_adi_label)
                        .addGap(11, 11, 11)
                        .addComponent(musteri_telefon_text, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(80, 80, 80)
                        .addComponent(masaustu_checkbox)
                        .addGap(23, 23, 23)
                        .addComponent(gomulu_checkbox)
                        .addGap(93, 93, 93)
                        .addComponent(varsayilan_konum_text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(210, 210, 210)
                        .addComponent(son_tarih_date, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(proje_tanimi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(560, 560, 560)
                        .addComponent(konum_label, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(ilk_tarih_date, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addComponent(pcb_checkbox))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addComponent(mobil_checkbox))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(560, 560, 560)
                        .addComponent(konum_text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(320, 320, 320)
                        .addComponent(musteri_mail_text, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(320, 320, 320)
                        .addComponent(musteri_ad_text, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(560, 560, 560)
                        .addComponent(gozat_buton))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(son_tarih_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addComponent(sematik_checkbox))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(geri_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(290, 290, 290)
                        .addComponent(musteri_not_label, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(610, 610, 610)
                        .addComponent(varsayilan_konum_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(islemler_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(proje_adi_text, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(para_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(ilk_tarih_label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(230, 230, 230)
                        .addComponent(kaydet_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(440, 440, 440)
                        .addComponent(web_checkbox))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(210, 210, 210)
                        .addComponent(para_text, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(proje_adi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(440, 440, 440)
                        .addComponent(donanim_checkbox))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(220, 220, 220)
                        .addComponent(para_combobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(290, 290, 290)
                        .addComponent(musteri_telefon_label, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(290, 290, 290)
                        .addComponent(temizle_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(380, 380, 380)
                        .addComponent(proje_tipi_label, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(65, 65, 65))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void geri_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geri_butonActionPerformed
      //Menu penceresine geri doner.
        menu nesne =new menu();
        nesne.setVisible(true);
       this.hide(); //yeni_proje penceresi gizlenir.
    }//GEN-LAST:event_geri_butonActionPerformed

    private void kaydet_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kaydet_butonActionPerformed
    if(proje_adi_text.getText()!=null || proje_adi_text.getText()!="" ) //Proje adinin bos olmamasi icin proje adini kontrol eder.
        {
            try 
            {
                Class.forName("com.mysql.jdbc.Driver");
                baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
                sorgu=baglanti.createStatement();
                sonuc=sorgu.executeQuery("select konum from dosya_konumu");
                while(sonuc.next())
                {
                    sdosyakonumu=sonuc.getString(1);               
                }
                //Dosya konumu varsayilan konumdan farkli mi diye kontrol edilir bu sayede
                //Kullanicinin istedigi konumda proje dosyasi olusturulur.
                if(sdosyakonumu!=konum_text.getText())
                {sdosyakonumu=konum_text.getText();}
                //Belirtilen konumda klasor referans nesnesi olusturulur.
                nesne_file = new File(sdosyakonumu);
                //Tanimlanan nesne File sinifinin methotlarini referans edebildiginden
                //mkdir() metodu klasor olusturulmak icin kullanilir.
                nesne_file.mkdir();
                // proje adi textfield komponentinin metni kullanilarak proje adinda klasor olusuturlur.
                nesne_file = new File(sdosyakonumu+"\\"+proje_adi_text.getText());
                nesne_file.mkdir();
                //file nesnesi ile olusacak dosyaya isim ve dosya uzantisi tanimlandi.
                //file = new File(sdosyakonumu+"\\"+jTextField10.getText()+"\\"+jTextField10.getText()+".text");
                // Dosya oluşturuluyor
                //nesne_file.createNewFile();
                PrintWriter yaz=new PrintWriter(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Proje Bilgilendirme.yldz");
                yaz.println("Proje Adı : "+proje_adi_text.getText());
                yaz.println("Fiyat : "+para_text.getText()+para_combobox.getSelectedItem());
                yaz.println("Müşteri Adı : "+musteri_ad_text.getText());
                yaz.println("Müşteri Telefon : "+musteri_telefon_text.getText());
                yaz.println("Müşteri Mail : "+musteri_mail_text.getText());
                yaz.println("Başlangıç Tarihi : "+((JTextField)ilk_tarih_date.getDateEditor().getUiComponent()).getText());
                yaz.println("Tahmini Bitiş Tarihi : "+((JTextField)son_tarih_date.getDateEditor().getUiComponent()).getText());                  
                String tur="";
                String tarih;
                Calendar cal=Calendar.getInstance();
                tarih=String.valueOf(cal.get(Calendar.YEAR))+"."+String.valueOf(cal.get(Calendar.MONTH)+1)+"."+String.valueOf(cal.get(Calendar.DAY_OF_MONTH))+"."+String.valueOf(cal.get(Calendar.HOUR_OF_DAY))+"."+String.valueOf(cal.get(Calendar.MINUTE))+"."+String.valueOf(cal.get(Calendar.SECOND));
                                                  
                //java.sql.Date tarihSql = new java.sql.Date();
                sorgu.executeUpdate("insert into projeler(adi,fiyat,amac,kaynak_dosya,tarih,kaynak_kod,kaynak_program,proje_durum) values('"+proje_adi_text.getText()+"','"+para_text.getText()+para_combobox.getSelectedItem()+"','"+proje_tanim_text.getText()+"','"+"Eklenmemiş"+"','"+tarih+"','"+"Eklenmemiş"+"','"+"Eklenmemiş"+"','"+"Devam Ediyor"+"')");                                        
                if(web_checkbox.isSelected())
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Web Yazılımı");
                    nesne_file.mkdir();
                    tur=tur+" Web";
                }
                if(masaustu_checkbox.isSelected())
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Masaüstü Uygulaması");
                    nesne_file.mkdir();
                    tur=tur+" Masaustu";
                }
                if(mobil_checkbox.isSelected())
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Mobil Yazılım");
                    nesne_file.mkdir();
                    tur=tur+" Mobil";
                }
                if(gomulu_checkbox.isSelected())
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Gömülü Yazılım");
                    nesne_file.mkdir();
                    tur=tur+" Gomulu";
                }
                if(donanim_checkbox.isSelected() && pcb_checkbox.isSelected() && sematik_checkbox.isSelected())
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Donanım");
                    nesne_file.mkdir();
                    tur=tur+" Donanım";
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Donanım\\PCB");
                    nesne_file.mkdir();
                    tur=tur+" PCB";
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Donanım\\Şematik");
                    nesne_file.mkdir();
                    tur=tur+" Şematik";
                }
                if(pcb_checkbox.isSelected() && sematik_checkbox.isSelected()==false)
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\PCB");
                    nesne_file.mkdir();
                    tur=tur+" PCB";
                }
                if(sematik_checkbox.isSelected() && pcb_checkbox.isSelected()==false)
                {
                    nesne_file=new File(sdosyakonumu+"\\"+proje_adi_text.getText()+"\\Şematik");
                    nesne_file.mkdir();
                    tur=tur+" Şematik";
                }
                yaz.println("Proje Türü : "+tur);
                yaz.println("Proje Tanımı : "+proje_tanim_text.getText());
                if(yaz!=null)
                yaz.close();
                JOptionPane.showMessageDialog(null,"Proje Kaydınız Başarılı Bir Şekilde Oluşturuldu.","Bilgilendirme",JOptionPane.WARNING_MESSAGE);
            }
                catch (ClassNotFoundException ex)
                {
                    Logger.getLogger(yeni_proje.class.getName()).log(Level.SEVERE, null, ex);
                }  
                catch (SQLException ex) 
                {
                       Logger.getLogger(yeni_proje.class.getName()).log(Level.SEVERE, null, ex);
                } 
                catch (FileNotFoundException ex) 
                {
                        Logger.getLogger(yeni_proje.class.getName()).log(Level.SEVERE, null, ex);
                } 
                catch (IOException ex) 
                {
                        Logger.getLogger(yeni_proje.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
        else if(proje_adi_text.getText()==null || proje_adi_text.getText()=="" || proje_adi_text.getText()==" ")
        {
           JOptionPane.showMessageDialog(null,"Beklenmeyen Bir Hata Oluştu Tekrar Deneyiniz!","Hata",JOptionPane.WARNING_MESSAGE);

        }
    }//GEN-LAST:event_kaydet_butonActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        //Menu penceresi acilir.
          menu nesne=new menu();
          nesne.setVisible(true);
        this.hide();    //Sİfre degistirme penceresi gizlenir.
    }//GEN-LAST:event_jButton13ActionPerformed

    private void gozat_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gozat_butonActionPerformed

       int returnVal=jfcdosya_sec.showOpenDialog(this);
       if (returnVal == JFileChooser.APPROVE_OPTION) 
       {       
       nesne_file=jfcdosya_sec.getSelectedFile();
       sdosyakonumu=nesne_file.getAbsolutePath();
       konum_text.setText(sdosyakonumu+"\\Projeler");
        }
    }//GEN-LAST:event_gozat_butonActionPerformed

    private void donanim_checkboxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_donanim_checkboxMouseClicked
        if(donanim_checkbox.isSelected()==true)
        {
            pcb_checkbox.setSelected(true);
            sematik_checkbox.setSelected(true);
        }
        else if(donanim_checkbox.isSelected()==false)
        {
            pcb_checkbox.setSelected(false);
            sematik_checkbox.setSelected(false);
        }
    }//GEN-LAST:event_donanim_checkboxMouseClicked

    private void pcb_checkboxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pcb_checkboxMouseClicked
       if(pcb_checkbox.isSelected()==true && sematik_checkbox.isSelected()==true)
        {
            donanim_checkbox.setSelected(true);
        }
        else if(pcb_checkbox.isSelected()==false || sematik_checkbox.isSelected()==false)
        {
            donanim_checkbox.setSelected(false);
        }
    }//GEN-LAST:event_pcb_checkboxMouseClicked

    private void sematik_checkboxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sematik_checkboxMouseClicked
        if(pcb_checkbox.isSelected()==true && sematik_checkbox.isSelected()==true)
        {
            donanim_checkbox.setSelected(true);
        }
        else if(pcb_checkbox.isSelected()==false || sematik_checkbox.isSelected()==false)
        {
            donanim_checkbox.setSelected(false);
        }
    }//GEN-LAST:event_sematik_checkboxMouseClicked

    private void proje_adi_textMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proje_adi_textMouseClicked
        proje_adi_text.setText("");
    }//GEN-LAST:event_proje_adi_textMouseClicked

    private void geri_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_geri_butonMouseEntered
        geri_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_geri_butonMouseEntered

    private void kaydet_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kaydet_butonMouseEntered
        kaydet_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_kaydet_butonMouseEntered

    private void temizle_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_temizle_butonMouseEntered
        temizle_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_temizle_butonMouseEntered

    private void para_comboboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_para_comboboxMouseEntered
        para_combobox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_para_comboboxMouseEntered

    private void gozat_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gozat_butonMouseEntered
        gozat_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_gozat_butonMouseEntered

    private void masaustu_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_masaustu_checkboxMouseEntered
        masaustu_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_masaustu_checkboxMouseEntered

    private void gomulu_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gomulu_checkboxMouseEntered
        gomulu_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_gomulu_checkboxMouseEntered

    private void web_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_web_checkboxMouseEntered
        web_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_web_checkboxMouseEntered

    private void mobil_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mobil_checkboxMouseEntered
        mobil_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_mobil_checkboxMouseEntered

    private void donanim_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_donanim_checkboxMouseEntered
        donanim_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_donanim_checkboxMouseEntered

    private void pcb_checkboxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pcb_checkboxMouseEntered
        pcb_checkbox.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_pcb_checkboxMouseEntered

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new yeni_proje().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox donanim_checkbox;
    private javax.swing.JButton geri_buton;
    private javax.swing.JCheckBox gomulu_checkbox;
    private javax.swing.JButton gozat_buton;
    private com.toedter.calendar.JDateChooser ilk_tarih_date;
    private javax.swing.JLabel ilk_tarih_label;
    private javax.swing.JLabel islemler_label;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar3;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField9;
    public javax.swing.JButton kaydet_buton;
    private javax.swing.JLabel konum_label;
    public java.awt.TextField konum_text;
    private javax.swing.JCheckBox masaustu_checkbox;
    private javax.swing.JCheckBox mobil_checkbox;
    private javax.swing.JTextField musteri_ad_text;
    public javax.swing.JLabel musteri_adi_label;
    private javax.swing.JTextField musteri_mail_text;
    private javax.swing.JLabel musteri_not_label;
    private javax.swing.JLabel musteri_telefon_label;
    private javax.swing.JTextField musteri_telefon_text;
    private javax.swing.JComboBox para_combobox;
    private javax.swing.JLabel para_label;
    private javax.swing.JTextField para_text;
    private javax.swing.JCheckBox pcb_checkbox;
    private javax.swing.JLabel proje_adi_label;
    public javax.swing.JTextField proje_adi_text;
    private javax.swing.JTextPane proje_tanim_text;
    private javax.swing.JLabel proje_tanimi_label;
    private javax.swing.JLabel proje_tipi_label;
    private javax.swing.JCheckBox sematik_checkbox;
    private com.toedter.calendar.JDateChooser son_tarih_date;
    private javax.swing.JLabel son_tarih_label;
    private javax.swing.JButton temizle_buton;
    private javax.swing.JLabel varsayilan_konum_label;
    private java.awt.TextField varsayilan_konum_text;
    private javax.swing.JCheckBox web_checkbox;
    // End of variables declaration//GEN-END:variables
}
