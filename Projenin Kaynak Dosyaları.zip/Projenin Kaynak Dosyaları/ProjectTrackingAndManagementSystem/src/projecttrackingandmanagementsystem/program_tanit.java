package projecttrackingandmanagementsystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class program_tanit extends javax.swing.JFrame 
{
    File file;
    final JFileChooser jfcdosya_sec=new JFileChooser();
    public String sdosyakonumu="C:\\Projeler";

    public program_tanit()
    {
        initComponents();       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        islemler_label = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Kullanacağınız Programları Sisteme Tanıtın");
        setResizable(false);

        jButton1.setBackground(new java.awt.Color(51, 153, 255));
        jButton1.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Kaydet");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 153, 255));
        jButton2.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Temizle");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jCheckBox4.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox4.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox4.setText("Gömülü Yazılım");
        jCheckBox4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox4MouseClicked(evt);
            }
        });

        jCheckBox8.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox8.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox8.setText("Mobil Yazılım");
        jCheckBox8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox8MouseClicked(evt);
            }
        });

        jCheckBox2.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox2.setText("Şematik");
        jCheckBox2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox2MouseClicked(evt);
            }
        });

        jCheckBox1.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox1.setText("PCB");
        jCheckBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox1MouseClicked(evt);
            }
        });

        jCheckBox5.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox5.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox5.setText("Donanım");
        jCheckBox5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox5MouseClicked(evt);
            }
        });

        jCheckBox6.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox6.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox6.setText("Web Yazılımı");
        jCheckBox6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox6MouseClicked(evt);
            }
        });

        jCheckBox3.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 14)); // NOI18N
        jCheckBox3.setForeground(new java.awt.Color(51, 51, 51));
        jCheckBox3.setText("Masaüstü Uygulaması");
        jCheckBox3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox3MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 51, 0));
        jLabel9.setText("Kullanıldığı Alan");

        jTextField1.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 16)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(51, 153, 255));

        jButton3.setBackground(new java.awt.Color(51, 153, 255));
        jButton3.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Gözat");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Dosya Konumu");

        jTextField2.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 16)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(51, 153, 255));

        jLabel1.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 51, 0));
        jLabel1.setText("Kullanacağınız Programları Sisteme Tanıtın");

        jButton4.setBackground(new java.awt.Color(51, 153, 255));
        jButton4.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Geri");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        islemler_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 16)); // NOI18N
        islemler_label.setForeground(new java.awt.Color(153, 51, 0));
        islemler_label.setText("İşlemler");

        jLabel5.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Programın Adı");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(islemler_label, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(229, 229, 229)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(30, 30, 30)
                                                .addComponent(jButton3))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(10, 10, 10)
                                                    .addComponent(jCheckBox2))
                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jCheckBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(50, 50, 50)
                                                .addComponent(jCheckBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(260, 260, 260)
                                                .addComponent(jCheckBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(50, 50, 50)
                                                .addComponent(jCheckBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(240, 240, 240)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(111, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(islemler_label, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(32, 32, 32)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(5, 5, 5)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jCheckBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox5MouseClicked
        if(jCheckBox5.isSelected()==true)
        {
            jCheckBox1.setSelected(true);
            jCheckBox2.setSelected(true);
        }
        else if(jCheckBox5.isSelected()==false)
        {
            jCheckBox1.setSelected(false);
            jCheckBox2.setSelected(false);
        }
        jCheckBox6.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox8.setSelected(false);
    }//GEN-LAST:event_jCheckBox5MouseClicked

    private void jCheckBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox1MouseClicked
        if(jCheckBox1.isSelected()==true && jCheckBox2.isSelected()==true)
        {
            jCheckBox5.setSelected(true);
        }
        else if(jCheckBox1.isSelected()==false || jCheckBox2.isSelected()==false)
        {
            jCheckBox5.setSelected(false);
        }
        jCheckBox6.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox8.setSelected(false);
    }//GEN-LAST:event_jCheckBox1MouseClicked

    private void jCheckBox2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox2MouseClicked
        if(jCheckBox1.isSelected()==true && jCheckBox2.isSelected()==true)
        {
            jCheckBox5.setSelected(true);
        }
        else if(jCheckBox1.isSelected()==false || jCheckBox2.isSelected()==false)
        {
            jCheckBox5.setSelected(false);
        }
        jCheckBox6.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox8.setSelected(false);
    }//GEN-LAST:event_jCheckBox2MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int returnVal=jfcdosya_sec.showOpenDialog(this);
       if (returnVal == JFileChooser.APPROVE_OPTION) 
       {       
       file=jfcdosya_sec.getSelectedFile();
       sdosyakonumu=file.getAbsolutePath();
       jTextField1.setText(sdosyakonumu);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      if(jCheckBox1.isSelected() || jCheckBox2.isSelected() || jCheckBox3.isSelected() || jCheckBox4.isSelected() || jCheckBox5.isSelected() || jCheckBox6.isSelected() || jCheckBox8.isSelected())
      {
          try {
          String tur="konum=";
          Class.forName("com.mysql.jdbc.Driver");
            Connection baglanti=null;
            baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
            java.sql.Statement komut = baglanti.createStatement();
            komut.executeUpdate("insert into program(ad,tur,konum) values('"+jTextField2.getText()+"','"+""+"','"+jTextField1.getText()+"')");
            if(jCheckBox6.isSelected())
         {
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected()==false && jCheckBox3.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Web' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected() && jCheckBox3.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Mobil' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected()==false && jCheckBox3.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Masaustu' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected() && jCheckBox3.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Masaustu-Mobil' where ad='"+jTextField2.getText()+"'");
             }
         }
            if(jCheckBox3.isSelected())
         {
             if(jCheckBox3.isSelected() && jCheckBox6.isSelected()==false && jCheckBox8.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Masaustu' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox3.isSelected() && jCheckBox8.isSelected() && jCheckBox6.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Masaustu-Mobil' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox3.isSelected() && jCheckBox8.isSelected()==false && jCheckBox6.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Masaustu' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected() && jCheckBox3.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Masaustu-Mobil' where ad='"+jTextField2.getText()+"'");
             }
         }
            if(jCheckBox8.isSelected())
         {
             if(jCheckBox8.isSelected() && jCheckBox6.isSelected()==false && jCheckBox3.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Mobil' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox8.isSelected() && jCheckBox6.isSelected() && jCheckBox3.isSelected()==false)
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Mobil' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox8.isSelected() && jCheckBox6.isSelected()==false && jCheckBox3.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Mobil-Masaustu' where ad='"+jTextField2.getText()+"'");
             }
             if(jCheckBox6.isSelected() && jCheckBox8.isSelected() && jCheckBox3.isSelected())
             {
                 komut.executeUpdate("UPDATE program SET tur='Web-Masaustu-Mobil' where ad='"+jTextField2.getText()+"'");
             }

         }
          if(jCheckBox4.isSelected())
         {
             komut.executeUpdate("UPDATE program SET tur ='Gomulu' where ad='"+jTextField2.getText()+"'");
         }
            else  if(jCheckBox5.isSelected() && jCheckBox1.isSelected() && jCheckBox2.isSelected())
         {
             komut.executeUpdate("UPDATE program SET tur ='Donanım' where ad='"+jTextField2.getText()+"'");
         }
            else if(jCheckBox1.isSelected() && jCheckBox2.isSelected()==false)
         {
             komut.executeUpdate("UPDATE program SET tur ='PCB' where ad='"+jTextField2.getText()+"'");
         }
            else  if(jCheckBox2.isSelected() && jCheckBox1.isSelected()==false)
         {
             komut.executeUpdate("UPDATE program SET tur ='Şematik' where ad='"+jTextField2.getText()+"'");
         }
           baglanti.close();
           JOptionPane.showMessageDialog(null,"Kullanılan program sisteme başarılı bir şekilde kaydedildi.","Bilgilendirme",JOptionPane.WARNING_MESSAGE);
      } catch (SQLException ex) {
        Logger.getLogger(program_tanit.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(program_tanit.class.getName()).log(Level.SEVERE, null, ex);
    }
      }
      else
      {
          JOptionPane.showMessageDialog(null,"Program Turu Seçilmedi.\nLütfen Tekrar Deneyiniz!","Hata",JOptionPane.WARNING_MESSAGE);
      }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        menu form =new menu();
        form.show();
        this.hide();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jCheckBox4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox4MouseClicked
        jCheckBox6.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox8.setSelected(false);
    }//GEN-LAST:event_jCheckBox4MouseClicked

    private void jCheckBox3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox3MouseClicked
        jCheckBox4.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
    }//GEN-LAST:event_jCheckBox3MouseClicked

    private void jCheckBox6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox6MouseClicked
        jCheckBox4.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
    }//GEN-LAST:event_jCheckBox6MouseClicked

    private void jCheckBox8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox8MouseClicked
        jCheckBox4.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
    }//GEN-LAST:event_jCheckBox8MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField2.setText("");
        jTextField1.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new program_tanit().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel islemler_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
