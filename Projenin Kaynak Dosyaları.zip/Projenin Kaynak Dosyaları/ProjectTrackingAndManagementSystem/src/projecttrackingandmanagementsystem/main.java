package projecttrackingandmanagementsystem;
//Kutuphaneler
import java.awt.Cursor;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class main extends javax.swing.JFrame 
{
    //Global Degiskenler
      //Veritabanı sorgu referans nesneleri
        Connection baglanti = null;  
        PreparedStatement sorgu=null;
        ResultSet sonuc = null;
      //Mouse imlec nesnesi
        Cursor imlec = new Cursor(Cursor.HAND_CURSOR);//İmlec sinifindan bir nesne turetilir ve yapilandirici metoduna bir imlec tanimlanir.
        //Yapilandirici metoduna tanimlanan imlec : Cursor.HAND_CURSOR
        
    public main()   //Penceremizin yapilandirici metodu 
    {
        initComponents();//tum komponentler gelistiricinin tanimladigi sekilde yuklenir.
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        username_label = new javax.swing.JLabel();
        username_text = new javax.swing.JTextField();
        password_label = new javax.swing.JLabel();
        password_change_label = new javax.swing.JLabel();
        userKey_text = new javax.swing.JPasswordField();
        giris_buton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Proje Takip Yönetim Sistemi - Kullanıcı Girişi");
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(760, 390));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(239, 239, 239));

        username_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 22)); // NOI18N
        username_label.setForeground(new java.awt.Color(0, 153, 204));
        username_label.setText("Kullanıcı Adı");

        username_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 24)); // NOI18N
        username_text.setForeground(new java.awt.Color(0, 255, 51));
        username_text.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                username_textMouseClicked(evt);
            }
        });

        password_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 22)); // NOI18N
        password_label.setForeground(new java.awt.Color(0, 153, 204));
        password_label.setText("Şifre");

        password_change_label.setBackground(java.awt.Color.white);
        password_change_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 24)); // NOI18N
        password_change_label.setForeground(new java.awt.Color(102, 153, 255));
        password_change_label.setText("Şifremi Unuttum");
        password_change_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                password_change_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                password_change_labelMouseEntered(evt);
            }
        });

        userKey_text.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 24)); // NOI18N
        userKey_text.setForeground(new java.awt.Color(0, 255, 51));
        userKey_text.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userKey_textMouseClicked(evt);
            }
        });
        userKey_text.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                userKey_textKeyPressed(evt);
            }
        });

        giris_buton.setBackground(new java.awt.Color(51, 153, 255));
        giris_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 18)); // NOI18N
        giris_buton.setForeground(java.awt.Color.white);
        giris_buton.setText("Giriş");
        giris_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                giris_butonMouseEntered(evt);
            }
        });
        giris_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                giris_butonActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projecttrackingandmanagementsystem/aaa.png"))); // NOI18N
        jLabel2.setToolTipText("");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projecttrackingandmanagementsystem/weer.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(281, 281, 281)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_change_label))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_label)
                    .addComponent(username_text, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_label)
                    .addComponent(userKey_text, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(giris_buton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1159, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(username_label)
                        .addGap(18, 18, 18)
                        .addComponent(username_text, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(password_label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(userKey_text, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(giris_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(password_change_label)))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void password_change_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_password_change_labelMouseClicked
       //Sifremi Unuttum penceresi açılır.
         sifremi_unuttum nesne = new sifremi_unuttum();
         nesne.show();    
         this.hide();//Main penceresi Gizlenir.
    }//GEN-LAST:event_password_change_labelMouseClicked

    private void giris_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_giris_butonActionPerformed
       try 
       {                                         
            Class.forName("com.mysql.jdbc.Driver");//Veritabanına baglanti surucusu tanimlandi.
            //Alt satirda veritabanimizin baglanti adresini tanimliyoruz.
            baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");                           
            sorgu=baglanti.prepareStatement("select * from user_login where username=? and password=?");//Veritabanimizda ki yapmak istediimiz sorgu burada tanimlanir.
            //Yukaridaki sorguda ? yerine textbox komponentlerinin degerleri onceden bilinmediginden ve degisken oldugundan
            //daha sonradan o degerler where sarti icine yuklenecektir. 
            //textbox komponentlerinin degerleri ? yerine yuklenir.
              sorgu.setString(1,username_text.getText());
              sorgu.setString(2,userKey_text.getText()); 
            //Sorgu calistirilir
              sonuc = sorgu.executeQuery();
            if(sonuc.next())    //Veritabaninda ki veriler ile komponentlerde ki verilerin eslesmesi karsilastirilir.
            {
                //Sonuclar ayni ise menu penceresi acilir ve kullanici basarili bir sekilde giris yapmis olur.
                menu form =new menu();
                form.show();
                this.hide();//Kullanici giris ekrani gizlenir.
            }
            else    //Degerler ayni degilse giris yapilamamis olur.
            {
                //Alt satirda kullaniciya uyari mesaji verir bu yapi uyari ve bilgilendirme mesaji icin kullanilir.
                  JOptionPane.showMessageDialog(null,"Yanlış Şifre Girdiniz","Hata",JOptionPane.WARNING_MESSAGE);
                //Texbox icinde ki yaziyi temizler.
                  username_text.setText("");
                  userKey_text.setText("");
            }
       }
       //Beklenmedik durumlar bu blokta degerlendirilir ve programin etkinligi surdurulur.
         catch (ClassNotFoundException ex) 
         {
                Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
         } 
         catch (SQLException ex) 
         {
                Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_giris_butonActionPerformed

    private void password_change_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_password_change_labelMouseEntered
        password_change_label.setCursor(imlec);//Mouse labelin uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_password_change_labelMouseEntered

    private void userKey_textKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userKey_textKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER)   //textbox icinde veri yazarken eger enter tusuna basarsak gerceklesecek islemler
        {
          try 
          {                                         
               Class.forName("com.mysql.jdbc.Driver");//Veritabanına baglanti surucusu tanimlandi.
               //Alt satirda veritabanimizin baglanti adresini tanimliyoruz.
               baglanti=DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");                           
               sorgu=baglanti.prepareStatement("select * from user_login where username=? and password=?");//Veritabanimizda ki yapmak istediimiz sorgu burada tanimlanir.
               //Yukaridaki sorguda ? yerine textbox komponentlerinin degerleri onceden bilinmediginden ve degisken oldugundan
               //daha sonradan o degerler where sarti icine yuklenecektir. 
               //textbox komponentlerinin degerleri ? yerine yuklenir.
                 sorgu.setString(1,username_text.getText());
                 sorgu.setString(2,userKey_text.getText()); 
               //Sorgu calistirilir
                 sonuc=sorgu.executeQuery();
               if(sonuc.next())    //Veritabaninda ki veriler ile komponentlerde ki verilerin eslesmesi karsilastirilir.
               {
                   //Sonuclar ayni ise menu penceresi acilir ve kullanici basarili bir sekilde giris yapmis olur.
                   menu form =new menu();
                   form.show();
                   this.hide();//Kullanici giris ekrani gizlenir.
               }
               else    //Degerler ayni degilse giris yapilamamis olur.
               {
                   //Alt satirda kullaniciya uyari mesaji verir bu yapi uyari ve bilgilendirme mesaji icin kullanilir.
                     JOptionPane.showMessageDialog(null,"Yanlış Şifre Girdiniz","Hata",JOptionPane.WARNING_MESSAGE);
                   username_text.setText("");
                   userKey_text.setText("");
               }
          }
          //Beklenmedik durumlar bu blokta degerlendirilir ve programin etkinligi surdurulur.
            catch (ClassNotFoundException ex) 
            {
                   Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (SQLException ex) 
            {
                   Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_userKey_textKeyPressed

    private void giris_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_giris_butonMouseEntered
        giris_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_giris_butonMouseEntered

    private void username_textMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_username_textMouseClicked
        username_text.setText("");//Textbox uzerinde tiklama yapildiginda icinde ki yaziyi temizler.
    }//GEN-LAST:event_username_textMouseClicked

    private void userKey_textMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userKey_textMouseClicked
        userKey_text.setText("");//Textbox uzerinde tiklama yapildiginda icinde ki yaziyi temizler.
    }//GEN-LAST:event_userKey_textMouseClicked

    public static void main(String args[])  //Penceremizin main metodu 
    {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater
        (new Runnable() 
        {
            public void run() 
            {
                new main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton giris_buton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel password_change_label;
    private javax.swing.JLabel password_label;
    private javax.swing.JPasswordField userKey_text;
    private javax.swing.JLabel username_label;
    private javax.swing.JTextField username_text;
    // End of variables declaration//GEN-END:variables
}
