package projecttrackingandmanagementsystem;
//Kutuphaneler
import java.awt.Color;
import java.awt.Cursor;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SwingConstants;
import static javax.swing.UIManager.getString;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class menu extends javax.swing.JFrame 
{
    //Global Degiskenler
      //Mouse imlec nesnesi
        Cursor imlec=new Cursor(Cursor.HAND_CURSOR);//İmlec sinifindan bir nesne turetilir ve yapilandirici metoduna bir imlec tanimlanir.
        //Yapilandirici metoduna tanimlanan imlec : Cursor.HAND_CURSOR
        int secim=-1;
        String proje_adi;
    public void projeleri_sirala()
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection baglanti=null;
            baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root"); //Mysql sunucusuna bağlandık
            Statement st = (Statement) baglanti.createStatement();
            try 
            (
                ResultSet rs = st.executeQuery("Select * from projeler order by tarih desc")) { //Veritabanındaki tabloya bağlandık               
                int colcount = rs.getMetaData().getColumnCount(); //Veritabanındaki tabloda kaç tane sütun var?
                DefaultTableModel tm = new DefaultTableModel(); //Model oluşturuyoruz
                for(int i = 0;i<=5;i++)
                    tm.addColumn(projeler_table.getColumnName(i)); //Tabloya sütun ekliyoruz veritabanımızdaki sütun ismiyle aynı olacak şekilde
                while(rs.next())
                    {
                        Object[] row = new Object[colcount];
                        for(int i=1;i<=colcount;i++)
                            row[i-1] = rs.getObject(i);
                        tm.addRow(row);
                    }
                Object[] row = new Object[colcount];
                colcount=18;                   
                    for(int i=1;i<=colcount;i++)
                    {tm.addRow(row);}
                projeler_table.setModel(tm);
            }
        } 
        catch (ClassNotFoundException | SQLException hata) 
        {
                 Object ex = null;
             Logger.getLogger(programlar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public menu() //Penceremizin yapilandirici metodu
    {
        initComponents();
        projeleri_sirala();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu7 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu10 = new javax.swing.JMenu();
        jMenu11 = new javax.swing.JMenu();
        jMenu12 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenu14 = new javax.swing.JMenu();
        popupMenu1 = new java.awt.PopupMenu();
        popupMenu2 = new java.awt.PopupMenu();
        popupMenu3 = new java.awt.PopupMenu();
        menuBar1 = new java.awt.MenuBar();
        menu1 = new java.awt.Menu();
        menu2 = new java.awt.Menu();
        menuBar2 = new java.awt.MenuBar();
        menu3 = new java.awt.Menu();
        menu4 = new java.awt.Menu();
        popupMenu4 = new java.awt.PopupMenu();
        popupMenu5 = new java.awt.PopupMenu();
        menuBar3 = new java.awt.MenuBar();
        menu5 = new java.awt.Menu();
        menu6 = new java.awt.Menu();
        menuBar4 = new java.awt.MenuBar();
        menu7 = new java.awt.Menu();
        menu8 = new java.awt.Menu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jButton8 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        guncelle_buton = new javax.swing.JButton();
        ac_buton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        projeler_table = new javax.swing.JTable();
        tum_projeler_label = new javax.swing.JLabel();
        sil_buton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        dosya_menu = new javax.swing.JMenu();
        yeni_proje_menu = new javax.swing.JMenuItem();
        kaynak_dosya_menu = new javax.swing.JMenuItem();
        proje_ac = new javax.swing.JMenuItem();
        kapat_menu = new javax.swing.JMenuItem();
        duzenle_menu = new javax.swing.JMenu();
        dosya_konumu_menu = new javax.swing.JMenuItem();
        program_tanit_menu = new javax.swing.JMenuItem();
        programlar_menu = new javax.swing.JMenuItem();
        hakkinda_menu = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        jMenu3.setText("File");
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar1.add(jMenu4);

        jMenu7.setText("jMenu7");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu5.setText("jMenu5");

        jMenu6.setText("jMenu6");

        jMenuItem1.setText("jMenuItem1");

        jMenu10.setText("jMenu10");

        jMenu11.setText("jMenu11");

        jMenu12.setText("jMenu12");

        jMenu8.setText("jMenu8");

        jMenu14.setText("jMenu14");

        popupMenu1.setLabel("popupMenu1");

        popupMenu2.setLabel("popupMenu2");

        popupMenu3.setLabel("popupMenu3");

        menu1.setLabel("File");
        menuBar1.add(menu1);

        menu2.setLabel("Edit");
        menuBar1.add(menu2);

        menu3.setLabel("File");
        menuBar2.add(menu3);

        menu4.setLabel("Edit");
        menuBar2.add(menu4);

        popupMenu4.setLabel("popupMenu4");

        popupMenu5.setLabel("popupMenu5");

        menu5.setLabel("File");
        menuBar3.add(menu5);

        menu6.setLabel("Edit");
        menuBar3.add(menu6);

        menu7.setLabel("File");
        menuBar4.add(menu7);

        menu8.setLabel("Edit");
        menuBar4.add(menu8);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton8.setText("Düzenle");

        jButton3.setText("jButton1");

        setTitle("Proje Takip Yönetim Sistemi - Anasayfa");
        setAlwaysOnTop(true);
        setBackground(java.awt.Color.white);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(java.awt.Color.white);
        setIconImages(null);
        setResizable(false);

        guncelle_buton.setBackground(new java.awt.Color(51, 153, 255));
        guncelle_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        guncelle_buton.setForeground(new java.awt.Color(255, 255, 255));
        guncelle_buton.setText("Güncelle");
        guncelle_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                guncelle_butonMouseEntered(evt);
            }
        });
        guncelle_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guncelle_butonActionPerformed(evt);
            }
        });

        ac_buton.setBackground(new java.awt.Color(51, 153, 255));
        ac_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        ac_buton.setForeground(new java.awt.Color(255, 255, 255));
        ac_buton.setText("Aç");
        ac_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ac_butonMouseEntered(evt);
            }
        });
        ac_buton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ac_butonActionPerformed(evt);
            }
        });

        projeler_table.setFont(new java.awt.Font("Lucida Sans Typewriter", 0, 12)); // NOI18N
        projeler_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Proje Adı", "Proje Fiyatı", "Proje Amacı", "Kaynak Kod Durumu", "Oluşturulma Tarihi", "Projenin Durumu"
            }
        ));
        projeler_table.setOpaque(false);
        projeler_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                projeler_tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(projeler_table);

        tum_projeler_label.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 36)); // NOI18N
        tum_projeler_label.setForeground(new java.awt.Color(153, 51, 0));
        tum_projeler_label.setText("Geliştirilen Tüm Projeler");

        sil_buton.setBackground(new java.awt.Color(51, 153, 255));
        sil_buton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 13)); // NOI18N
        sil_buton.setForeground(new java.awt.Color(255, 255, 255));
        sil_buton.setText("Sil");
        sil_buton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sil_butonMouseEntered(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projecttrackingandmanagementsystem/java-projeleri.jpg"))); // NOI18N
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        dosya_menu.setText("Dosya");
        dosya_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dosya_menuMouseEntered(evt);
            }
        });

        yeni_proje_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        yeni_proje_menu.setText("Yeni Proje");
        yeni_proje_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                yeni_proje_menuMouseEntered(evt);
            }
        });
        yeni_proje_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yeni_proje_menuActionPerformed(evt);
            }
        });
        dosya_menu.add(yeni_proje_menu);

        kaynak_dosya_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        kaynak_dosya_menu.setText("Kaynak Dosya Ekle");
        kaynak_dosya_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kaynak_dosya_menuMouseEntered(evt);
            }
        });
        kaynak_dosya_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kaynak_dosya_menuActionPerformed(evt);
            }
        });
        dosya_menu.add(kaynak_dosya_menu);

        proje_ac.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        proje_ac.setText("Proje Aç");
        proje_ac.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                proje_acMouseEntered(evt);
            }
        });
        proje_ac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                proje_acActionPerformed(evt);
            }
        });
        dosya_menu.add(proje_ac);

        kapat_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_MASK));
        kapat_menu.setText("Kapat");
        kapat_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kapat_menuMouseEntered(evt);
            }
        });
        kapat_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kapat_menuActionPerformed(evt);
            }
        });
        dosya_menu.add(kapat_menu);

        menuBar.add(dosya_menu);

        duzenle_menu.setText("Düzenle");
        duzenle_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                duzenle_menuMouseEntered(evt);
            }
        });

        dosya_konumu_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.ALT_MASK));
        dosya_konumu_menu.setText("Varsayılan Dosya Konumu");
        dosya_konumu_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dosya_konumu_menuMouseEntered(evt);
            }
        });
        dosya_konumu_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosya_konumu_menuActionPerformed(evt);
            }
        });
        duzenle_menu.add(dosya_konumu_menu);

        program_tanit_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.ALT_MASK));
        program_tanit_menu.setText("Uygulamalarınızı Tanıtın");
        program_tanit_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                program_tanit_menuMouseEntered(evt);
            }
        });
        program_tanit_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                program_tanit_menuActionPerformed(evt);
            }
        });
        duzenle_menu.add(program_tanit_menu);

        programlar_menu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_MASK));
        programlar_menu.setText("Geliştiricinin Uygulamaları");
        programlar_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                programlar_menuMouseEntered(evt);
            }
        });
        programlar_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                programlar_menuActionPerformed(evt);
            }
        });
        duzenle_menu.add(programlar_menu);

        menuBar.add(duzenle_menu);

        hakkinda_menu.setText("Yardım");
        hakkinda_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hakkinda_menuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                hakkinda_menuMouseEntered(evt);
            }
        });

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.SHIFT_MASK));
        jMenuItem2.setText("Hakkında");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        hakkinda_menu.add(jMenuItem2);

        menuBar.add(hakkinda_menu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(270, 270, 270)
                .addComponent(tum_projeler_label, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(930, 930, 930)
                .addComponent(sil_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(ac_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(760, 760, 760)
                .addComponent(guncelle_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 980, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1040, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(tum_projeler_label)
                        .addGap(378, 378, 378)
                        .addComponent(sil_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(460, 460, 460)
                        .addComponent(ac_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(460, 460, 460)
                        .addComponent(guncelle_buton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void yeni_proje_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yeni_proje_menuActionPerformed
       //Yeni proje penceresi acilir.
         yeni_proje nesne =new yeni_proje();
         nesne.setVisible(true);
       this.hide();//menu penceresi gizlenir.
    }//GEN-LAST:event_yeni_proje_menuActionPerformed

    private void dosya_konumu_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosya_konumu_menuActionPerformed
            try //Beklenmedik durumlara karsi programin etkinligi icin kullanilir.
            {
                //Dosya konumu penceresi acilir.
                  dosya_konumu form =new dosya_konumu();
                  form.show();
                this.hide();  //Menu penceresi gizlenir.  
            } 
            catch (ClassNotFoundException ex) //Beklenmedik durumlar gerceklestiginde bu blokta ki islemler yapilir.
            {
                Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_dosya_konumu_menuActionPerformed

    private void program_tanit_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_program_tanit_menuActionPerformed
        //Program tanit penceresi acilir.
          program_tanit form =new program_tanit();
          form.show();
        this.setVisible(false); //Menu penceresi gizlenir.
    }//GEN-LAST:event_program_tanit_menuActionPerformed

    private void programlar_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_programlar_menuActionPerformed
        //Dosya konumu penceresi acilir.
          programlar form =new programlar();
          form.show();
        this.hide();    //Menu penceresi gizlenir.
    }//GEN-LAST:event_programlar_menuActionPerformed

    private void proje_acActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_proje_acActionPerformed
        //Proje Ac penceresi acilir.
          proje_ac form =new proje_ac();
          form.show();
          //form.toFront();
          this.hide();
        //this.show(true);   //Menu penceresi gizlenir.
    }//GEN-LAST:event_proje_acActionPerformed

    private void kapat_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kapat_menuActionPerformed
        System.exit(1);//Uygulamadan cikis yapmamizi saglar.
    }//GEN-LAST:event_kapat_menuActionPerformed

    private void ac_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ac_butonMouseEntered
        ac_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_ac_butonMouseEntered

    private void hakkinda_menuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hakkinda_menuMouseClicked
        
    }//GEN-LAST:event_hakkinda_menuMouseClicked

    private void guncelle_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guncelle_butonMouseEntered
        guncelle_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_guncelle_butonMouseEntered

    private void sil_butonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sil_butonMouseEntered
        sil_buton.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_sil_butonMouseEntered

    private void hakkinda_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hakkinda_menuMouseEntered
        hakkinda_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_hakkinda_menuMouseEntered

    private void duzenle_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_duzenle_menuMouseEntered
        duzenle_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_duzenle_menuMouseEntered

    private void dosya_konumu_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dosya_konumu_menuMouseEntered
        dosya_konumu_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_dosya_konumu_menuMouseEntered

    private void program_tanit_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_program_tanit_menuMouseEntered
        program_tanit_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_program_tanit_menuMouseEntered

    private void programlar_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_programlar_menuMouseEntered
        programlar_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_programlar_menuMouseEntered

    private void dosya_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dosya_menuMouseEntered
        dosya_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_dosya_menuMouseEntered

    private void yeni_proje_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_yeni_proje_menuMouseEntered
        yeni_proje_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_yeni_proje_menuMouseEntered

    private void kaynak_dosya_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kaynak_dosya_menuMouseEntered
        kaynak_dosya_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_kaynak_dosya_menuMouseEntered

    private void proje_acMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proje_acMouseEntered
        proje_ac.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_proje_acMouseEntered

    private void kapat_menuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kapat_menuMouseEntered
        kapat_menu.setCursor(imlec);//Mouse butonun uzerine geldiginde mouse imleci tanimlanan imlec gorunumunu alir.
    }//GEN-LAST:event_kapat_menuMouseEntered

    private void kaynak_dosya_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kaynak_dosya_menuActionPerformed
        //Kaynak dosya ekle penceresi acilir.
          kaynak_dosya_ekle form =new kaynak_dosya_ekle();
          form.setVisible(true);
        this.hide();    //Menu penceresi gizlenir.
    }//GEN-LAST:event_kaynak_dosya_menuActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        //Hakkinda penceresi acilir.
          hakkinda form =new hakkinda();
          form.setVisible(true);
          this.toBack(); //Menu penceresi gizlenir.
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void projeler_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_projeler_tableMouseClicked
       secim=projeler_table.getSelectedRow();
       proje_adi=(String) projeler_table.getValueAt(secim, 0);
    }//GEN-LAST:event_projeler_tableMouseClicked

    private void ac_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ac_butonActionPerformed
        try 
        {
                Class.forName("com.mysql.jdbc.Driver");
                Connection baglanti=null;
                baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
                Statement ifade=baglanti.createStatement();
                ResultSet rs=ifade.executeQuery("select kaynak_program,kaynak_dosya from projeler where adi='"+proje_adi+"'");
                String kaynak_kod = null,kaynak_program = null;
                while(rs.next())
                {
                    kaynak_kod=rs.getString("kaynak_dosya");
                    kaynak_program=rs.getString("kaynak_program");
                }
                Process p=Runtime.getRuntime().exec("cmd /c start \""+kaynak_program+"\" \""+kaynak_kod+"\"");
        }     
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_ac_butonActionPerformed

    private void guncelle_butonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guncelle_butonActionPerformed

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection baglanti=null;
                baglanti = DriverManager.getConnection("jdbc:mysql://localhost:3306/proje_takip_yonetim?autoReconnect=true&useSSL=false","root","root");
                Statement ifade=(Statement) baglanti.createStatement();
                String durum=(String) projeler_table.getValueAt(secim, 5);
                ifade.execute("UPDATE projeler SET proje_durum ='"+durum+"' where adi='"+proje_adi+"'"); //Sql sorgusu ile password degeri guncellenir.
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(menu.class.getName()).log(Level.SEVERE, null, ex);
            }
            projeleri_sirala();
    }//GEN-LAST:event_guncelle_butonActionPerformed
    public static void main(String args[]) //Penceremizin main metodu.
    {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ac_buton;
    private javax.swing.JMenuItem dosya_konumu_menu;
    private javax.swing.JMenu dosya_menu;
    private javax.swing.JMenu duzenle_menu;
    private javax.swing.JButton guncelle_buton;
    private javax.swing.JMenu hakkinda_menu;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton8;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem kapat_menu;
    private javax.swing.JMenuItem kaynak_dosya_menu;
    private java.awt.Menu menu1;
    private java.awt.Menu menu2;
    private java.awt.Menu menu3;
    private java.awt.Menu menu4;
    private java.awt.Menu menu5;
    private java.awt.Menu menu6;
    private java.awt.Menu menu7;
    private java.awt.Menu menu8;
    private javax.swing.JMenuBar menuBar;
    private java.awt.MenuBar menuBar1;
    private java.awt.MenuBar menuBar2;
    private java.awt.MenuBar menuBar3;
    private java.awt.MenuBar menuBar4;
    private java.awt.PopupMenu popupMenu1;
    private java.awt.PopupMenu popupMenu2;
    private java.awt.PopupMenu popupMenu3;
    private java.awt.PopupMenu popupMenu4;
    private java.awt.PopupMenu popupMenu5;
    private javax.swing.JMenuItem program_tanit_menu;
    private javax.swing.JMenuItem programlar_menu;
    private javax.swing.JMenuItem proje_ac;
    private javax.swing.JTable projeler_table;
    private javax.swing.JButton sil_buton;
    private javax.swing.JLabel tum_projeler_label;
    private javax.swing.JMenuItem yeni_proje_menu;
    // End of variables declaration//GEN-END:variables
}
